﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Input.Touch;

namespace BombermanMG
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        //MB// Declaration des textures utilisées
        Texture2D Background, B1, B2, bloc_des, flamme, b_f, b_b, b_v, bombe;

        //MB// Declaration de nos objets
        Partie partie;
        Bomber Bomber1;
        Bomber Bomber2;

        // Keyboard states used to determine key presses
        KeyboardState currentKeyboardState;
        KeyboardState previousKeyboardState;

        // Gamepad states used to determine button presses
        GamePadState currentGamePadState;
        GamePadState previousGamePadState;

        //Mouse states used to track Mouse button press
        MouseState currentMouseState;
        MouseState previousMouseState;

        // A movement speed for the player
        float playerMoveSpeed;

        //MB// Taille d'une case (Tile  ~= Case en anglais)
        //MB// Ca change en fonction du "zoom" là c'est 64 pour la taille de fenêtre que j'ai faite
        const int TileSize = 64;

        //MB// pour la gestion des bombes
        //MB// Nombre de passages dans la boucle
        const int delay = 150;        

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            //MB// Pour régler la largeur de la fenêtre (c'est 960 = 15*64 comme les tableux font du 13*11 sans compter les bords)
            graphics.PreferredBackBufferWidth = 15 * TileSize;
            //MB// Pour régler la hauteur de la fenêtre (c'est 832 = 13*64 comme les tableux font du 13*11 sans compter le bords)
            graphics.PreferredBackBufferHeight = 13 * TileSize;
            graphics.ApplyChanges();

        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            //MB// Game Parameters
            //MBB/ Il faut mettre un f à la fin des valeurs parce qu'en C# par défaut quand tu tapes un nombre réel c'est un double
            playerMoveSpeed = 8.0f;

            //MB// Game Objects
            partie = new Partie();
            Bomber1 = new Bomber();
            Bomber2 = new Bomber();
            base.Initialize();
            
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            Background = Content.Load<Texture2D>("FondJeu");
            B1 = Content.Load<Texture2D>("B1");
            B2 = Content.Load<Texture2D>("B2");
            bombe = Content.Load<Texture2D>("Bombe");
            bloc_des = Content.Load<Texture2D>("Mur");
            flamme = Content.Load<Texture2D>("Flameche2");

            //Load the bomber resources
            Vector2 bomber1position = new Vector2(TileSize, TileSize);
            Vector2 bomber2position = new Vector2(13 * TileSize, 11 * TileSize);

            Bomber1.Initialize(bomber1position, B1);
            Bomber2.Initialize(bomber2position, B2);
            partie.Initialize(bloc_des, bombe,flamme);

        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here
            // Save the previous state of the keyboard and game pad so we can determine single key/button presses
            previousGamePadState = currentGamePadState;
            previousKeyboardState = currentKeyboardState;

            // Read the current state of the keyboard and gamepad and store it
            currentKeyboardState = Keyboard.GetState();
            currentGamePadState = GamePad.GetState(PlayerIndex.One);

            //Update the bomber
            Update_Bomber1(gameTime);
            Update_Bomber2(gameTime);
            Update_Bomb(gameTime);

            base.Update(gameTime);
        }

        //MB//Je crée une autre fonction pour pas avoir de bordel dans Update()
        //MB//En fait on va faire des sous fonctions Update_truc() qu'on appellera dans Update()
        private void Update_Bomber1(GameTime gameTime)
        {
            //MB// Le code de gestion des déplacements est expliqué dans Update_Bomber2
            //MB// Pourquoi ? me direz-vous et bien parce que j'ai bossé sur bomber2 pour tester
            //MB// Encore un pourquoi ? Très enfantin. Je suppose qu'à question bête réponse bête:
            //MB// PARCE QUE

            //MB// Y'a juste ça que j'exlique ici
            //MB// C'est un essai pour limiter les mouvements en diagonale parce qu'ils peuvent ignorer les collisions sous certaines conditions
            bool movement = true;
            
            if (currentKeyboardState.IsKeyDown(Keys.Q) == true && movement)
            {
                if (Bomber1.pos.X > TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber1.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber1.pos.Y / TileSize) - 1] != 2)
                    {
                        Bomber1.pos.X -= playerMoveSpeed;
                        
                    }
                    movement = false;
                }

            }
            else if (previousKeyboardState.IsKeyDown(Keys.Q))
            {
                while (Bomber1.pos.X != ((int)Bomber1.pos.X / TileSize) * TileSize)
                {
                    Bomber1.pos.X--;
                    
                }
                movement = false;
            }

            if (currentKeyboardState.IsKeyDown(Keys.D) == true &&movement)
            {
                if (Bomber1.pos.X < 13 * TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 2)
                    {
                        Bomber1.pos.X += playerMoveSpeed;
                        
                    }
                    movement = false;
                }

            }
            else if (previousKeyboardState.IsKeyDown(Keys.D))
            {
                while (Bomber1.pos.X != ((int)Bomber1.pos.X / TileSize) * TileSize)
                {
                    Bomber1.pos.X++;
                    
                }
                movement = false;
            }

            if (currentKeyboardState.IsKeyDown(Keys.Z) == true && movement)
            {
                if (Bomber1.pos.Y > TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 2] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 2] != 2)
                    {
                        Bomber1.pos.Y -= playerMoveSpeed;
                        
                    }
                    movement = false;
                }

            }
            else if (previousKeyboardState.IsKeyDown(Keys.Z))
            {
                while (Bomber1.pos.Y != ((int)Bomber1.pos.Y / TileSize) * TileSize)
                {
                    Bomber1.pos.Y--;
                    
                }
                movement = false;
            }


            if (currentKeyboardState.IsKeyDown(Keys.S) == true &&movement)
            {
                if (Bomber1.pos.Y < 11 * TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)] != 2)
                    {
                        Bomber1.pos.Y += playerMoveSpeed;
                        
                    }
                    movement = false;
                }
            }
            else if (previousKeyboardState.IsKeyDown(Keys.S))
            {
                while (Bomber1.pos.Y != ((int)Bomber1.pos.Y / TileSize) * TileSize)
                {
                    Bomber1.pos.Y++;
                    
                }
                movement = false;
            }


            if (currentKeyboardState.IsKeyDown(Keys.Space) == true)
            {
                partie.tab_blocs[(int)(Bomber1.pos.X / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] = 41;
                partie.tab_bombes[(int)(Bomber1.pos.X / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] = delay;
            }
        }

        private void Update_Bomber2(GameTime gameTime)
        {
            bool movement = true;
            // Use the Keyboard / Dpad
            if (currentKeyboardState.IsKeyDown(Keys.Left)&&movement)
            {
                //MB//On regarde si on dépasse pas les bords du tableau
                if (Bomber2.pos.X > TileSize)
                {
                    //MB// Gestion de collision
                    //MB//                    
                    //MB// Le type de bloc sur le terrain est renseigné dans partie.tab_blocs[]
                    //MB// On convertit la position du bomber à l'écran, donnée en pixels, en une position dans le tableau
                    //MB// Pour ça on divise la position à l'écran par Tilesize(64) puisque le tableau fait 13*11
                    //MB// Et que la partie jouable de l'écran fait 13Tilesize * 11Tilesize
                    //MB// On garde la partie entière de cette division au cas où on serait en mouvement
                    //MB// On obtient donc un nombre entre 1 et 13. On lui retranche 1 car l'indice du tableau va de 0 à 12
                    //MB// Maintenant comme c'est un déplacement à gauche on regarde la case à gauche du bomber dans le tableau
                    //MB// Il suffit de faire -1 sur pos.X du bomber. C'est pour ça qu'on a -2 pour le X et -1 pour le Y
                    //MB// L'histoire du +Tilesize -1 c'est pour prendre en compte non pas le bord gauche du bomber (par défaut)
                    //MB// Si on effectue le test sur le bord gauche, il suffit qu'on se décale d'un pixel et la condition
                    //MB// n'est plus vraie. En faisant -Tilesize +1 on prend en compte le bord droit du bomber
                    //MB// Et comme ça la condition devient fausse uniquement quand le bomber est entièrement dans la case
                    if (partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber2.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber2.pos.Y / TileSize) - 1] != 2)
                    {
                        Bomber2.pos.X -= playerMoveSpeed;
                        movement = false;
                    }

                }
            }
            //MB//Si lors de la précédente boucle de l'Update la touche gauche était enfoncée
            //MB// c'est qu'on était en train de se déplacer
            //MB// Du coup on veut finir le déplacement sur une case entière
            else if (previousKeyboardState.IsKeyDown(Keys.Left))
            {
                //MB// J'ai fait une boucle en espérant que ça rende le truc un peu plus fluide mais elle est faite
                //MB// tellement vite qu'on le voit pas.
                //MB// Du coup j'ai voulu diminuer l'incrément mais ça a foutu la merde je sais pas pourquoi
                //MB// Je fais -1 ça va mais -0.1 OH MON DIEU JE VAIS TOUT A GAUCHE
                //MB// Et pourtant la position c'est un float et pour afficher je prends la partie entière
                //MB// La partie entière de 561.9 (au pif) je crois pas que ça se situe tout à gauche de l'écran
                while (Bomber2.pos.X != ((int)Bomber2.pos.X / TileSize) * TileSize)
                {
                    Bomber2.pos.X--;
                }
                movement = false;
            }



            if (currentKeyboardState.IsKeyDown(Keys.Right)&&movement)
            {
                if (Bomber2.pos.X < 13 * TileSize)
                {
                    //MB// Là du coup comme on veut aller à droite on prend en compte le bord gauche du bomber. Donc pas de +tilesize -1
                    //MB// Et la case du tableau que l'on veut vérifier n'est plus ppos du bomber -1 mais +1.
                    if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize), (int)(Bomber2.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize), (int)(Bomber2.pos.Y / TileSize) - 1] != 2)
                    {
                        Bomber2.pos.X += playerMoveSpeed;
                        movement = false;
                    }

                }
            }
            else if (previousKeyboardState.IsKeyDown(Keys.Right))
            {
                while (Bomber2.pos.X != ((int)Bomber2.pos.X / TileSize) * TileSize)
                {
                    Bomber2.pos.X++;
                }
                movement = false;
            }

            if (currentKeyboardState.IsKeyDown(Keys.Up)&&movement)
            {
                if (Bomber2.pos.Y > TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 2)
                    {
                        Bomber2.pos.Y -= playerMoveSpeed;
                        movement = false;
                    }
                }
            }
            else if (previousKeyboardState.IsKeyDown(Keys.Up))
            {
                while (Bomber2.pos.Y != ((int)Bomber2.pos.Y / TileSize) * TileSize)
                {
                    Bomber2.pos.Y--;
                }
                movement = false;
            }

            if (currentKeyboardState.IsKeyDown(Keys.Down)&&movement)
            {
                if (Bomber2.pos.Y < 11 * TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y) / TileSize)] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y) / TileSize)] != 2)
                    {
                        Bomber2.pos.Y += playerMoveSpeed;
                        movement = false;
                    }
                }
            }
            else if (previousKeyboardState.IsKeyDown(Keys.Down))
            {
                while (Bomber2.pos.Y != ((int)Bomber2.pos.Y / TileSize) * TileSize)
                {
                    Bomber2.pos.Y++;
                }
                movement = false;
            }

            if (currentKeyboardState.IsKeyDown(Keys.NumPad0))
            {
                partie.tab_blocs[(int)(Bomber2.pos.X / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] = 42;
                partie.tab_bombes[(int)(Bomber2.pos.X / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] = delay;
            }
            
        }

        private void Update_Bomb(GameTime gameTime)
        {            
            for(int i=0;i<13;i++)
            {
                for(int j =0;j<11;j++)
                {
                    if(partie.tab_bombes[i,j] >0)
                    {
                        partie.tab_bombes[i, j]--;
                        if(partie.tab_bombes[i,j]==0)
                        {
                            Explosion(i,j);
                        }
                    }
                }
            }            
        }

        private void Explosion(int x,int y)
        {
            int p;            
            switch (partie.tab_blocs[x,y])
            {
                case 41:
                    partie.tab_blocs[x, y] = 0;
                    partie.tab_bombes[x, y] = 0;
                    p = Bomber1.puissance;
                    //4 boucles pour les 4 directions
                    for(int i =0;i<=p;i++)
                    {
                        if(x+i <13)
                        {
                            switch (partie.tab_blocs[x + i, y])
                            {
                                case 0:
                                    partie.tab_blocs[x + i, y] = 3;
                                    break;
                                case 2:
                                    partie.tab_blocs[x + i, y] = 21;
                                    //Si on rencontre un mur on arrête l'explosion dans cette direction
                                    i = p;
                                    break;
                            }
                        }
                        
                    }
                    for (int i = 0; i <= p; i++)
                    {
                        if(y+i < 11)
                        {
                            switch (partie.tab_blocs[x, y + i])
                            {
                                case 0:
                                    partie.tab_blocs[x, y + i] = 3;
                                    break;
                                case 2:
                                    partie.tab_blocs[x, y + i] = 21;
                                    //Si on rencontre un mur on arrête l'explosion dans cette direction
                                    i = p;
                                    break;
                            }
                        }
                        
                    }
                    for (int i = 0; i <= p; i++)
                    {
                        if(x-i>=0)
                        {
                            switch (partie.tab_blocs[x - i, y])
                            {
                                case 0:
                                    partie.tab_blocs[x - i, y] = 3;
                                    break;
                                case 2:
                                    partie.tab_blocs[x - i, y] = 21;
                                    //Si on rencontre un mur on arrête l'explosion dans cette direction
                                    i = p;
                                    break;
                            }
                        }
                        
                    }
                    for (int i = 0; i <= p; i++)
                    {
                        if(y-i>=0)
                        {
                            switch (partie.tab_blocs[x, y - i])
                            {
                                case 0:
                                    partie.tab_blocs[x, y - i] = 3;
                                    break;
                                case 2:
                                    partie.tab_blocs[x, y - i] = 21;
                                    //Si on rencontre un mur on arrête l'explosion dans cette direction
                                    i = p;
                                    break;
                            }
                        }
                        
                    }
                    break;

                case 42:
                    //MB// tout pareil mais on prend la puissance du joueur 2
                    partie.tab_blocs[x, y] = 0;
                    partie.tab_bombes[x, y] = 0;
                    p = Bomber2.puissance;                    
                    for (int i = 0; i <= p; i++)
                    {
                        if (x+i <13)
                        {
                            switch (partie.tab_blocs[x+i, y])
                            {
                                case 0:
                                    partie.tab_blocs[x+i, y] = 3;
                                    break;
                                case 2:
                                    partie.tab_blocs[x+i, y] = 21;
                                    i = p;
                                    break;
                            }
                        }
                    }
                    for (int i = 0; i <= p; i++)
                    {
                        if (y+i < 11)
                        {
                            switch (partie.tab_blocs[x, y + i])
                            {
                                case 0:
                                    partie.tab_blocs[x, y + i] = 3;
                                    break;
                                case 2:
                                    partie.tab_blocs[x, y + i] = 21;
                                    i = p;
                                    break;
                            }
                        }
                    }
                    for (int i = 0; i <= p; i++)
                    {
                        if (x-i >= 0)
                        {
                            switch (partie.tab_blocs[x-i, y])
                            {
                                case 0:
                                    partie.tab_blocs[x-i, y] = 3;
                                    break;
                                case 2:
                                    partie.tab_blocs[x-i, y] = 21;
                                    i = p;
                                    break;
                            }
                        }
                    }
                    for (int i = 0; i <= p; i++)
                    {
                        if (y-i >= 0)
                        {
                            switch (partie.tab_blocs[x, y - i])
                            {
                                case 0:
                                    partie.tab_blocs[x, y - i] = 3;
                                    break;
                                case 2:
                                    partie.tab_blocs[x, y - i] = 21;
                                    i = p;
                                    break;
                            }
                        }
                    }
                    break;
            }
        }

        
        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here

            //start drawing
            spriteBatch.Begin();

            spriteBatch.Draw(Background, new Rectangle(0, 0, 960, 832), Color.White);
            Bomber1.Draw(spriteBatch);
            Bomber2.Draw(spriteBatch);
            partie.Draw(spriteBatch);

            //Stop drawing
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
