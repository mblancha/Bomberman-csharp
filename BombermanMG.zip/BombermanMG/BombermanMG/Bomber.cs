﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace BombermanMG
{
    class Bomber
    {
        //MB// Oui les attributs sont en public c'est pour éviter de se faire chier LOL
        //MB// en vrai c'est pour pouvoir y accéder depuis Game1.cs
        //MB// Enfin on nous a toujours dit que normalement il fallait pas blablabla
        //MB// Mais les tutos que j'ai trouvés le font et c'est plus simple
        public int vitesse, puissance, nb_bombes, nb_bombes_pos,dir;
        public bool kick, punch, skull, alive;
        public Vector2 pos;

        public Texture2D texture_h,texture_b,texture_g,texture_d;

        // Get the width of the bomber texture

        public int Width
        {
            get { return texture_h.Width; }
        }
        
        // Get the height of the bomber texture
        public int Height
        {
            get { return texture_h.Height; }
        }

        public void Initialize(Vector2 p, Texture2D txtrh,Texture2D txtrb,Texture2D txtrg,Texture2D txtrd)
        {
            vitesse = 8;
            puissance = 1;
            nb_bombes = 1;
            nb_bombes_pos = 0;
            kick = false;
            punch = false;
            skull = false;
            alive = true;
            pos = p;
            dir = 1;
            texture_h = txtrh;
            texture_b = txtrb;
            texture_g = txtrg;
            texture_d = txtrd;

        }



        public void Draw(SpriteBatch spritebatch)
        {
            switch (dir)
            {
                case 0:
                    spritebatch.Draw(texture_h, new Rectangle((int)pos.X, (int)pos.Y, 64, 64), Color.White);
                    break;
                case 1:
                    spritebatch.Draw(texture_b, new Rectangle((int)pos.X, (int)pos.Y, 64, 64), Color.White);
                    break;
                case 2:
                    spritebatch.Draw(texture_g, new Rectangle((int)pos.X, (int)pos.Y, 64, 64), Color.White);
                    break;
                case 3:
                    spritebatch.Draw(texture_d, new Rectangle((int)pos.X, (int)pos.Y, 64, 64), Color.White);
                    break;
            }
        }
    }

    public class Partie
    {        
        //MB// C'est comme ça qu'on déclare les tableaux en c# c'est chelou
        public int[,] tab_blocs = new int[13, 11];
        public int[,] tab_bonus = new int[13, 11];
        public int[,] tab_bombes = new int[13, 11];

        private Texture2D bloc_des,flamme,bombe1,bombe2,mur_d;
        private uint anim_bombes;
                
        //On verra plus tard pour les autre textures
        public void Initialize(Texture2D b_d, Texture2D bo1,Texture2D bo2,Texture2D f,Texture2D mur_det) //, Texture2D f, Texture2D b_f, Texture2D b_b, Texture2D b_v)
        {
            bloc_des = b_d;
            bombe1 = bo1;
            bombe2 = bo2;
            flamme = f;
            mur_d = mur_det;

            anim_bombes = 0;
            /*
            bonus_f = b_f;
            bonus_b = b_b;
            bonus_v = b_v;*/

            //Initialisation du tableau de blocs
            /*
            Pas de bloc = 0
            Bloc indestructible = 1
            Bloc destructible = 2
            Bloc en cours de destruction = 21
            Flamme = 3
            Bombe j1 = 41
            Bombe j2 = 42
            */

            uint i, j;
            Random aleatoire = new Random();

            

            // On pose les blocs destructibles et on fait le tableau de bombes
            for (i = 0; i < 13; i++)
            {
                for (j = 0; j < 11; j++)
                {
                    //On remplit le tableau de bombes de 0
                    tab_bombes[i, j] = 0;

                    //On veut pas des blocs partout
                    //On génère un nombre aléatoire entre 0 et 7
                    // S'il est >= 2 on met un bloc
                    int g = aleatoire.Next(3);
                    if (g >= 1)
                    {
                        tab_blocs[i, j] = 2;
                    }
                    else
                    {
                        tab_blocs[i, j] = 0;
                    }
                }
            }

            //On pose les blocs indestructibles
            for (i = 1; i < 13; i = i + 2)
            {
                for (j = 1; j < 11; j = j + 2)
                {
                    tab_blocs[i, j] = 1;
                }
            }

            //On enlève les éventuels blocs des spawns des joueurs
            tab_blocs[0, 0] = 0;
            tab_blocs[1, 0] = 0;
            tab_blocs[0, 1] = 0;
            tab_blocs[12, 10] = 0;
            tab_blocs[12, 9] = 0;
            tab_blocs[11, 10] = 0;

            //Maintenant on fait un autre tableau avec les bonus
            //Parce que comme les bonus  se trouve là où il y a des blocs destructibles et on puet pas empiler avec
            // un seul tableau
            //Pas de bonus = 0
            //bonus flamme = 1
            //bonus bombe = 2
            //bonus vitesse = 3
            //Enfin je vais peut être faire autrement et ne calculer la génération des bonus qu'à la destruction d'un bloc

            for (i = 0; i < 13; i++)
            {
                for (j = 0; j < 11; j++)
                {
                    if (tab_blocs[i, j] == 2)
                    {
                        int b = aleatoire.Next(10);
                        if (b >=4)
                        {
                            int t = aleatoire.Next(3);
                            switch (t)
                            {
                                case 0:
                                    tab_bonus[i, j] = 1;
                                    break;
                                case 1:
                                    tab_bonus[i, j] = 2;
                                    break;
                                case 2:
                                    tab_bonus[i, j] = 3;
                                    break;
                            }
                        }
                    }
                }
            }
            
        }

        public void Draw(SpriteBatch spritebatch)
        {
            int i, j;
            for(i=0;i<13;i++)
            {
                for(j=0;j<11;j++)
                {
                    switch (tab_blocs[i,j])
                    {
                        case 2:
                            spritebatch.Draw(bloc_des, new Rectangle((i + 1) * 64, (j + 1) * 64, 64, 64), Color.White);
                            break;
                        case 21:
                            spritebatch.Draw(mur_d, new Rectangle((i+1)*64, (j+1)*64 ,64,64), Color.White);
                            break;
                        case 3:
                            spritebatch.Draw(flamme, new Rectangle((i + 1) * 64, (j + 1) * 64, 64, 64), Color.White);
                            break;
                        case 41:
                            if(anim_bombes == 0)
                            {
                                spritebatch.Draw(bombe1, new Rectangle((i + 1) * 64, (j + 1) * 64, 64, 64), Color.White);
                                anim_bombes = 1;
                            }
                            else
                            {
                                spritebatch.Draw(bombe2, new Rectangle((i + 1) * 64, (j + 1) * 64, 64, 64), Color.White);
                                anim_bombes = 0;
                            }
                                                        
                            break;
                        case 42:
                            spritebatch.Draw(bombe1, new Rectangle((i + 1) * 64, (j + 1) * 64, 64, 64), Color.White);
                            break;
                    }
                }
            }
        }
    }      

    
        
}



