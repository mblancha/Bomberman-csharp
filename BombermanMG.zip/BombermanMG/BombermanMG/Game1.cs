﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Input.Touch;

namespace BombermanMG
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {       

        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        //MB// Declaration des textures utilisées
        Texture2D Background, bloc_des, flamme, b_f, b_b, b_v, bombe1,bombe2,mur_det;
        Texture2D B1H, B1B, B1G, B1D;
        Texture2D B2H, B2B, B2G, B2D;
        Texture2D playbutton, quitbutton, optionsbutton, menubackground;

        Vector2 playbutton_pos, optionsbutton_pos, quitbutton_pos;

        //MB// Declaration de nos objets
        Partie partie;
        Bomber Bomber1;
        Bomber Bomber2;

        //MB// Etat du jeu
        //MB// Pour l'instant on se sert pas de Paused
        enum gamestate
        {
            Menu,
            Paused,
            Running
        }
        gamestate _gamestate;

        // Keyboard states used to determine key presses
        KeyboardState currentKeyboardState;
        KeyboardState previousKeyboardState;

        // Gamepad states used to determine button presses
        GamePadState currentGamePadState;
        GamePadState previousGamePadState;

        //Mouse states used to track Mouse button press
        MouseState currentMouseState;
        MouseState previousMouseState;        

        //MB// Taille d'une case (Tile  ~= Case en anglais)
        //MB// Ca change en fonction du "zoom" là c'est 64 pour la taille de fenêtre que j'ai faite
        const int TileSize = 64;

        //MB// pour la gestion des bombes
        //MB// Nombre de passages dans la boucle
        const int delay = 125;        

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            //MB// Pour régler la largeur de la fenêtre (c'est 960 = 15*64 comme les tableux font du 13*11 sans compter les bords)
            graphics.PreferredBackBufferWidth = 15 * TileSize;
            //MB// Pour régler la hauteur de la fenêtre (c'est 832 = 13*64 comme les tableux font du 13*11 sans compter le bords)
            graphics.PreferredBackBufferHeight = 13 * TileSize;
            //MB// Pour centrer la fenêtre
            Window.Position = new Point((GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Width / 2) - (graphics.PreferredBackBufferWidth / 2), (GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Height / 2) - (graphics.PreferredBackBufferHeight / 2));
            graphics.ApplyChanges();

        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            //MB// Game Objects
            partie = new Partie();
            Bomber1 = new Bomber();
            Bomber2 = new Bomber();
            playbutton_pos = new Vector2(3 * TileSize +TileSize/2, 4 * TileSize+TileSize/2);
            optionsbutton_pos = new Vector2(3 * TileSize+TileSize/2, 7 * TileSize+TileSize/2);
            quitbutton_pos = new Vector2(3 * TileSize+TileSize/2, 10 * TileSize+TileSize/2);
            _gamestate = gamestate.Menu;
            base.Initialize();
            
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            Background = Content.Load<Texture2D>("FondJeu");
            B1H = Content.Load<Texture2D>("B1H");
            B1B = Content.Load<Texture2D>("B1B");
            B1G = Content.Load<Texture2D>("B1G");
            B1D = Content.Load<Texture2D>("B1D");
            B2H = Content.Load<Texture2D>("B2H");
            B2B = Content.Load<Texture2D>("B2B");
            B2G = Content.Load<Texture2D>("B2G");
            B2D = Content.Load<Texture2D>("B2D");
            bombe1 = Content.Load<Texture2D>("Bombe1");
            bombe2 = Content.Load<Texture2D>("Bombe2");
            bloc_des = Content.Load<Texture2D>("Mur");
            flamme = Content.Load<Texture2D>("Flamme");
            mur_det = Content.Load<Texture2D>("Mur_det");
            b_b = Content.Load<Texture2D>("Bonus_b");
            b_f = Content.Load<Texture2D>("Bonus_f");
            menubackground = Content.Load<Texture2D>("MenuBG2");
            playbutton = Content.Load<Texture2D>("Play_button1");
            optionsbutton = Content.Load<Texture2D>("Play_button2");
            quitbutton = Content.Load<Texture2D>("Quit_button");

            //Load the bomber resources
            Vector2 bomber1position = new Vector2(TileSize, TileSize);
            Vector2 bomber2position = new Vector2(13 * TileSize, 11 * TileSize);            

            Bomber1.Initialize(bomber1position, B1H,B1B,B1G,B1D);
            Bomber2.Initialize(bomber2position, B2H,B2B,B2G,B2D);
            partie.Initialize(bloc_des, bombe1,bombe2,flamme,mur_det);

        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            this.IsMouseVisible = true;
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Quit();

            // TODO: Add your update logic here
            // Save the previous state of the keyboard and game pad so we can determine single key/button presses
            previousMouseState = currentMouseState;
            previousKeyboardState = currentKeyboardState;

            // Read the current state of the keyboard and gamepad and store it
            currentKeyboardState = Keyboard.GetState();
            currentMouseState = Mouse.GetState();

            if(previousMouseState.LeftButton == ButtonState.Pressed && currentMouseState.LeftButton == ButtonState.Released)
            {
                MouseClicked(currentMouseState.X, currentMouseState.Y);
            }

            //Update the bomber
            Update_Bomber1(gameTime);
            if (Bomber1.alive == false)
            {
                Quit();
            }
            Update_Bomber2(gameTime);
            if (Bomber2.alive == false)
            {
                Quit();
            }
            Update_Bomb(gameTime);

            base.Update(gameTime);
        }

        //MB//Je crée une autre fonction pour pas avoir de bordel dans Update()
        //MB//En fait on va faire des sous fonctions Update_truc() qu'on appellera dans Update()
        private void Update_Bomber1(GameTime gameTime)
        {
            //MB// Le code de gestion des déplacements est expliqué dans Update_Bomber2
            //MB// Pourquoi ? me direz-vous et bien parce que j'ai bossé sur bomber2 pour tester
            //MB// Encore un pourquoi ? Très enfantin. Je suppose qu'à question bête réponse bête:
            //MB// PARCE QUE

            //MB// Y'a juste ça que j'exlique ici
            //MB// C'est un essai pour limiter les mouvements en diagonale parce qu'ils peuvent ignorer les collisions sous certaines conditions
            bool movement = true;

            //MB// Là on va tester si le joueuer est dans une flamme
            if (partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] == 3)
            {
                Bomber1.alive = false;
            }

            if (currentKeyboardState.IsKeyDown(Keys.Q) == true && movement)
            {
                if (Bomber1.pos.X > TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber1.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber1.pos.Y / TileSize) - 1] != 2
                        && partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber1.pos.Y / TileSize) - 1] != 41
                        && partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber1.pos.Y / TileSize) - 1] != 42)
                    {
                        Bomber1.pos.X -= Bomber1.vitesse;
                        Bomber1.dir = 2;
                        //MB// Pareil ici on teste si le joueur est dans un flamme
                        if (partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] == 3)
                        {
                            Bomber1.alive = false;
                        }
                        movement = false;
                    }                 
                }

            }
            else if (previousKeyboardState.IsKeyDown(Keys.Q))
            {                   
                while (Bomber1.pos.X != ((int)Bomber1.pos.X / TileSize) * TileSize)
                {
                    Bomber1.pos.X-=Bomber1.vitesse;
                    Bomber1.dir = 2;
                    if (partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] == 3)
                    {
                        Bomber1.alive = false;
                    }
                }
                movement = false;
            }

            if (currentKeyboardState.IsKeyDown(Keys.D) == true &&movement)
            {
                if (Bomber1.pos.X < 13 * TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 2
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 41
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 42)
                    {
                        Bomber1.pos.X += Bomber1.vitesse;
                        Bomber1.dir = 3;
                        if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize)-1, (int)(Bomber1.pos.Y / TileSize) - 1] == 3)
                        {
                            Bomber1.alive = false;
                        }
                    }
                    movement = false;
                }

            }
            else if (previousKeyboardState.IsKeyDown(Keys.D))
            {
                if(partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 2
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 41
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 42)
                {
                    while (Bomber1.pos.X != ((int)Bomber1.pos.X / TileSize) * TileSize)
                    {
                        Bomber1.pos.X++;
                        Bomber1.dir = 3;
                        if (partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] == 3)
                        {
                            Bomber1.alive = false;
                        }
                    }
                }
                
                movement = false;
            }

            if (currentKeyboardState.IsKeyDown(Keys.Z) == true && movement)
            {
                if (Bomber1.pos.Y > TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 2] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 2] != 2
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 2] != 41
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 2] != 42)
                    {
                        Bomber1.pos.Y -= Bomber1.vitesse;
                        Bomber1.dir = 0;
                        if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 1] == 3)
                        {
                            Bomber1.alive = false;
                        }
                    }
                    movement = false;
                }

            }
            else if (previousKeyboardState.IsKeyDown(Keys.Z))
            {
                while (Bomber1.pos.Y != ((int)Bomber1.pos.Y / TileSize) * TileSize)
                {
                    Bomber1.pos.Y--;
                    Bomber1.dir = 0;
                    if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 1] == 3)
                    {
                        Bomber1.alive = false;
                    }
                }
                movement = false;
            }


            if (currentKeyboardState.IsKeyDown(Keys.S) == true &&movement)
            {
                if (Bomber1.pos.Y < 11 * TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)] != 2
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)] != 41
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)] != 42)
                    {
                        Bomber1.pos.Y += Bomber1.vitesse;
                        Bomber1.dir = 1;
                        if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)-1] == 3)
                        {
                            Bomber1.alive = false;
                        }
                    }
                    movement = false;
                }
            }
            else if (previousKeyboardState.IsKeyDown(Keys.S))
            {
                while (Bomber1.pos.Y != ((int)Bomber1.pos.Y / TileSize) * TileSize)
                {
                    Bomber1.pos.Y++;
                    Bomber1.dir = 1;
                    if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)-1] == 3)
                    {
                        Bomber1.alive = false;
                    }
                }
                movement = false;
            }

            //MB// Pose des bombes
            if (currentKeyboardState.IsKeyDown(Keys.Space) == true)
            {
                if(Bomber1.nb_bombes_pos < Bomber1.nb_bombes)
                {
                    partie.tab_blocs[(int)(Bomber1.pos.X / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] = 41;
                    partie.tab_bombes[(int)(Bomber1.pos.X / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] = delay;
                    Bomber1.nb_bombes_pos++;
                }
                
            }

            //MB// Gestion des bonus
            if(partie.tab_blocs[(int)(Bomber1.pos.X/TileSize)-1, (int)(Bomber1.pos.Y/TileSize)-1] == 0)
            {
                switch (partie.tab_bonus[(int)(Bomber1.pos.X / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1])
                {
                    case 1:
                        Bomber1.puissance++;
                        partie.tab_bonus[(int)(Bomber1.pos.X / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] = 0;
                        break;
                    case 2:
                        Bomber1.nb_bombes++;
                        partie.tab_bonus[(int)(Bomber1.pos.X / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] = 0;
                        break;
                    /*case 3:
                        Bomber1.vitesse++;
                        break;*/
                }
            }
            
        }
        
        private void Update_Bomber2(GameTime gameTime)
        {
            bool movement = true;

            if (partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] == 3)
            {
                Bomber2.alive = false;
            }
            // Use the Keyboard / Dpad
            if (currentKeyboardState.IsKeyDown(Keys.Left)&&movement)
            {
                //MB//On regarde si on dépasse pas les bords du tableau
                if (Bomber2.pos.X > TileSize)
                {
                    //MB// Gestion de collision
                    //MB//                    
                    //MB// Le type de bloc sur le terrain est renseigné dans partie.tab_blocs[]
                    //MB// On convertit la position du bomber à l'écran, donnée en pixels, en une position dans le tableau
                    //MB// Pour ça on divise la position à l'écran par Tilesize(64) puisque le tableau fait 13*11
                    //MB// Et que la partie jouable de l'écran fait 13Tilesize * 11Tilesize
                    //MB// On garde la partie entière de cette division au cas où on serait en mouvement
                    //MB// On obtient donc un nombre entre 1 et 13. On lui retranche 1 car l'indice du tableau va de 0 à 12
                    //MB// Maintenant comme c'est un déplacement à gauche on regarde la case à gauche du bomber dans le tableau
                    //MB// Il suffit de faire -1 sur pos.X du bomber. C'est pour ça qu'on a -2 pour le X et -1 pour le Y
                    //MB// L'histoire du +Tilesize -1 c'est pour prendre en compte non pas le bord gauche du bomber (par défaut)
                    //MB// Si on effectue le test sur le bord gauche, il suffit qu'on se décale d'un pixel et la condition
                    //MB// n'est plus vraie. En faisant -Tilesize +1 on prend en compte le bord droit du bomber
                    //MB// Et comme ça la condition devient fausse uniquement quand le bomber est entièrement dans la case
                    if (partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber2.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber2.pos.Y / TileSize) - 1] != 2
                        && partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber2.pos.Y / TileSize) - 1] != 41
                        && partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber2.pos.Y / TileSize) - 1] != 42)
                    {
                        Bomber2.pos.X -= Bomber2.vitesse;
                        Bomber2.dir = 2;
                        if (partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] == 3)
                        {
                            Bomber2.alive = false;
                        }
                    }
                    movement = false;

                }
            }
            //MB//Si lors de la précédente boucle de l'Update la touche gauche était enfoncée
            //MB// c'est qu'on était en train de se déplacer
            //MB// Du coup on veut finir le déplacement sur une case entière
            else if (previousKeyboardState.IsKeyDown(Keys.Left))
            {
                //MB// J'ai fait une boucle en espérant que ça rende le truc un peu plus fluide mais elle est faite
                //MB// tellement vite qu'on le voit pas.
                //MB// Du coup j'ai voulu diminuer l'incrément mais ça a foutu la merde je sais pas pourquoi
                //MB// Je fais -1 ça va mais -0.1 OH MON DIEU JE VAIS TOUT A GAUCHE
                //MB// Et pourtant la position c'est un float et pour afficher je prends la partie entière
                //MB// La partie entière de 561.9 (au pif) je crois pas que ça se situe tout à gauche de l'écran
                while (Bomber2.pos.X != ((int)Bomber2.pos.X / TileSize) * TileSize)
                {
                    Bomber2.pos.X--;
                    Bomber2.dir = 2;
                    if (partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] == 3)
                    {
                        Bomber2.alive = false;
                    }
                }
                movement = false;
            }



            if (currentKeyboardState.IsKeyDown(Keys.Right)&&movement)
            {
                if (Bomber2.pos.X < 13 * TileSize)
                {
                    //MB// Là du coup comme on veut aller à droite on prend en compte le bord gauche du bomber. Donc pas de +tilesize -1
                    //MB// Et la case du tableau que l'on veut vérifier n'est plus ppos du bomber -1 mais +1.
                    if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize), (int)(Bomber2.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize), (int)(Bomber2.pos.Y / TileSize) - 1] != 2
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize), (int)(Bomber2.pos.Y / TileSize) - 1] != 41
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize), (int)(Bomber2.pos.Y / TileSize) - 1] != 42)
                    {
                        Bomber2.pos.X += Bomber2.vitesse;
                        Bomber2.dir = 3;
                        if (partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] == 3)
                        {
                            Bomber2.alive = false;
                        }
                    }
                    movement = false;

                }
            }
            else if (previousKeyboardState.IsKeyDown(Keys.Right))
            {
                if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 2
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 41
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 42)
                {
                    Bomber2.pos.Y -= Bomber1.vitesse;
                    Bomber2.dir = 0;
                    if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 1] == 3)
                    {
                        Bomber2.alive = false;
                    }
                }
                movement = false;
            }

            if (currentKeyboardState.IsKeyDown(Keys.Up)&&movement)
            {
                if (Bomber2.pos.Y > TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 2
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 41
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 42)
                    {
                        Bomber2.pos.Y -= Bomber2.vitesse;
                        Bomber2.dir = 0;
                        if (partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] == 3)
                        {
                            Bomber2.alive = false;
                        }
                    }
                    movement = false;
                }
            }
            else if (previousKeyboardState.IsKeyDown(Keys.Up))
            {
                while (Bomber2.pos.Y != ((int)Bomber2.pos.Y / TileSize) * TileSize)
                {
                    Bomber2.pos.Y--;
                    Bomber2.dir = 0;
                    if (partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] == 3)
                    {
                        Bomber2.alive = false;
                    }
                }
                movement = false;
            }

            if (currentKeyboardState.IsKeyDown(Keys.Down)&&movement)
            {
                if (Bomber2.pos.Y < 11 * TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y) / TileSize)] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y) / TileSize)] != 2
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y) / TileSize)] != 41
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y) / TileSize)] != 42)
                    {
                        Bomber2.pos.Y += Bomber2.vitesse;
                        Bomber2.dir = 1;
                        if (partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] == 3)
                        {
                            Bomber2.alive = false;
                        }
                    }
                    movement = false;
                }
            }
            else if (previousKeyboardState.IsKeyDown(Keys.Down))
            {
                while (Bomber2.pos.Y != ((int)Bomber2.pos.Y / TileSize) * TileSize)
                {
                    Bomber2.pos.Y++;
                    Bomber2.dir = 1;
                    if (partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] == 3)
                    {
                        Bomber2.alive = false;
                    }
                }
                movement = false;
            }

            if (currentKeyboardState.IsKeyDown(Keys.NumPad0))
            {
                if(Bomber2.nb_bombes_pos < Bomber2.nb_bombes)
                {
                    partie.tab_blocs[(int)(Bomber2.pos.X / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] = 42;
                    partie.tab_bombes[(int)(Bomber2.pos.X / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] = delay;
                    Bomber2.nb_bombes_pos++;
                }
            }

            //MB// Gestion des bonus
            if (partie.tab_blocs[(int)(Bomber2.pos.X/TileSize)-1, (int)(Bomber2.pos.Y/TileSize)-1] == 0)
            {
                switch (partie.tab_bonus[(int)(Bomber2.pos.X / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1])
                {
                    case 1:
                        Bomber2.puissance++;
                        partie.tab_bonus[(int)(Bomber2.pos.X / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] = 0;
                        break;
                    case 2:
                        Bomber2.nb_bombes++;
                        partie.tab_bonus[(int)(Bomber2.pos.X / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] = 0;
                        break;
                    /*case 3:
                        Bomber2.vitesse++;
                        break;*/
                }
            }

        }

        private void Update_Bomb(GameTime gameTime)
        {            
            for(int i=0;i<13;i++)
            {
                for(int j =0;j<11;j++)
                {
                    if(partie.tab_bombes[i,j] >0)
                    {
                        partie.tab_bombes[i, j]--;
                        if(partie.tab_bombes[i,j]==0)
                        {
                            Explosion(i,j);
                        }
                    }
                    if(partie.tab_bombes[i,j]<0)
                    {
                        partie.tab_bombes[i, j]++;
                        if(partie.tab_bombes[i,j]==0)
                        {
                            partie.tab_blocs[i, j] = 0;
                        }
                    }
                }
            }            
        }

        private void Explosion(int x,int y)
        {
            int p;            
            switch (partie.tab_blocs[x,y])
            {
                case 41:
                    partie.tab_blocs[x, y] = 0;
                    partie.tab_bombes[x, y] = 0;
                    p = Bomber1.puissance;
                    Bomber1.nb_bombes_pos--;
                    //4 boucles pour les 4 directions
                    for(int i =0;i<=p;i++)
                    {
                        if(x+i <13)
                        {
                            switch (partie.tab_blocs[x + i, y])
                            {
                                case 0:
                                    partie.tab_blocs[x + i, y] = 3;
                                    partie.tab_bombes[x + i, y] = -delay/2;
                                    if(partie.tab_bonus[x+i,y] !=0)
                                    {
                                        partie.tab_bonus[x + i, y] = 0;
                                    }
                                    break;
                                case 2:
                                    partie.tab_blocs[x + i, y] = 21;
                                    partie.tab_bombes[x + i, y] = -delay/2;
                                    //Si on rencontre un mur on arrête l'explosion dans cette direction
                                    i = p+1;
                                    break;
                                case 1:
                                    i = p + 1;
                                    break;
                            }
                        }
                        
                    }
                    for (int i = 0; i <= p; i++)
                    {
                        if(y+i < 11)
                        {
                            switch (partie.tab_blocs[x, y + i])
                            {
                                case 0:
                                    partie.tab_blocs[x, y + i] = 3;
                                    partie.tab_bombes[x , y +i] = -delay/2;
                                    if (partie.tab_bonus[x, y+i] != 0)
                                    {
                                        partie.tab_bonus[x, y+i] = 0;
                                    }
                                    break;
                                case 2:
                                    partie.tab_blocs[x, y + i] = 21;
                                    partie.tab_bombes[x , y+i] = -delay / 2;
                                    //Si on rencontre un mur on arrête l'explosion dans cette direction
                                    i = p+1;
                                    break;
                                case 1:
                                    i = p + 1;
                                    break;
                            }
                        }
                        
                    }
                    for (int i = 0; i <= p; i++)
                    {
                        if(x-i>=0)
                        {
                            switch (partie.tab_blocs[x - i, y])
                            {
                                case 0:
                                    partie.tab_blocs[x - i, y] = 3;
                                    partie.tab_bombes[x - i, y] = -delay/2;
                                    if (partie.tab_bonus[x - i, y] != 0)
                                    {
                                        partie.tab_bonus[x - i, y] = 0;
                                    }
                                    break;
                                case 2:
                                    partie.tab_blocs[x - i, y] = 21;
                                    partie.tab_bombes[x - i, y] = -delay / 2;
                                    //Si on rencontre un mur on arrête l'explosion dans cette direction
                                    i = p;
                                    break;
                                case 1:
                                    i = p + 1;
                                    break;
                            }
                        }
                        
                    }
                    for (int i = 0; i <= p; i++)
                    {
                        if(y-i>=0)
                        {
                            switch (partie.tab_blocs[x, y - i])
                            {
                                case 0:
                                    partie.tab_blocs[x, y - i] = 3;
                                    partie.tab_bombes[x , y - i] = -delay/2;
                                    if (partie.tab_bonus[x, y-i] != 0)
                                    {
                                        partie.tab_bonus[x, y-i] = 0;
                                    }
                                    break;
                                case 2:
                                    partie.tab_blocs[x, y - i] = 21;
                                    partie.tab_bombes[x , y-i] = -delay / 2;
                                    //Si on rencontre un mur on arrête l'explosion dans cette direction
                                    i = p;
                                    break;
                                case 1:
                                    i = p + 1;
                                    break;
                            }
                        }
                        
                    }
                    break;

                case 42:
                    //MB// tout pareil mais on prend la puissance du joueur 2
                    partie.tab_blocs[x, y] = 0;
                    partie.tab_bombes[x, y] = 0;
                    p = Bomber2.puissance;
                    Bomber2.nb_bombes_pos--;
                    for (int i = 0; i <= p; i++)
                    {
                        if (x+i <13)
                        {
                            switch (partie.tab_blocs[x+i, y])
                            {
                                case 0:
                                    partie.tab_blocs[x+i, y] = 3;
                                    partie.tab_bombes[x + i, y] = -delay/2;
                                    if (partie.tab_bonus[x + i, y] != 0)
                                    {
                                        partie.tab_bonus[x + i, y] = 0;
                                    }
                                    break;
                                case 2:
                                    partie.tab_blocs[x+i, y] = 21;
                                    partie.tab_bombes[x + i, y] = -delay / 2;
                                    i = p;
                                    break;
                                case 1:
                                    i = p + 1;
                                    break;
                            }
                        }
                    }
                    for (int i = 0; i <= p; i++)
                    {
                        if (y+i < 11)
                        {
                            switch (partie.tab_blocs[x, y + i])
                            {
                                case 0:
                                    partie.tab_blocs[x, y + i] = 3;
                                    partie.tab_bombes[x , y+i] = -delay/2;
                                    if (partie.tab_bonus[x, y+i] != 0)
                                    {
                                        partie.tab_bonus[x, y+i] = 0;
                                    }
                                    break;
                                case 2:
                                    partie.tab_blocs[x, y + i] = 21;
                                    partie.tab_bombes[x , y+i] = -delay / 2;
                                    i = p;
                                    break;
                                case 1:
                                    i = p + 1;
                                    break;
                            }
                        }
                    }
                    for (int i = 0; i <= p; i++)
                    {
                        if (x-i >= 0)
                        {
                            switch (partie.tab_blocs[x-i, y])
                            {
                                case 0:
                                    partie.tab_blocs[x-i, y] = 3;
                                    partie.tab_bombes[x - i, y] = -delay/2;
                                    if (partie.tab_bonus[x - i, y] != 0)
                                    {
                                        partie.tab_bonus[x - i, y] = 0;
                                    }
                                    break;
                                case 2:
                                    partie.tab_blocs[x-i, y] = 21;
                                    partie.tab_bombes[x - i, y] = -delay / 2;
                                    i = p;
                                    break;
                                case 1:
                                    i = p + 1;
                                    break;
                            }
                        }
                    }
                    for (int i = 0; i <= p; i++)
                    {
                        if (y-i >= 0)
                        {
                            switch (partie.tab_blocs[x, y - i])
                            {
                                case 0:
                                    partie.tab_blocs[x, y - i] = 3;
                                    partie.tab_bombes[x , y-i] = -delay/2;
                                    if (partie.tab_bonus[x, y-i] != 0)
                                    {
                                        partie.tab_bonus[x, y-i] = 0;
                                    }
                                    break;
                                case 2:
                                    partie.tab_blocs[x, y - i] = 21;
                                    partie.tab_bombes[x , y-i] = -delay / 2;
                                    i = p;
                                    break;
                                case 1:
                                    i = p + 1;
                                    break;
                            }
                        }
                    }
                    break;
            }
        }

        //MB// J'ai fait la fonction d'affichage ici et pas dans la classe partie pour pas avoir 1256354 textures à passer en paramètre
        private void Draw_Bonus(SpriteBatch spriteBatch)
        {
            for(int i=0;i<13;i++)
            {
                for(int j=0;j<11;j++)
                {
                    if(partie.tab_blocs[i,j]==0)
                    {
                        switch (partie.tab_bonus[i, j])
                        {
                            case 1:
                                spriteBatch.Draw(b_f, new Rectangle((i + 1) * TileSize, (j + 1) * TileSize, TileSize, TileSize), Color.White);
                                break;
                            case 2:
                                spriteBatch.Draw(b_b, new Rectangle((i + 1) * TileSize, (j + 1) * TileSize, TileSize, TileSize), Color.White);
                                break;
                        }
                    }                    
                }
            }
        }


        //MB// Dans cette méthode on pourra rajouter le code de ce qu'on voudra faire en fin de partie
        private void Quit()
        {
            if(Bomber1.alive == false)
            {
                _gamestate = gamestate.Menu;                
            }
            else
            {
                _gamestate = gamestate.Menu;
            }
        }

        
        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here

            //start drawing
            spriteBatch.Begin();

            if(_gamestate == gamestate.Running)
            {
                spriteBatch.Draw(Background, new Rectangle(0, 0, 960, 832), Color.White);
                Bomber1.Draw(spriteBatch);
                Bomber2.Draw(spriteBatch);
                partie.Draw(spriteBatch);
                Draw_Bonus(spriteBatch);
            }

            if(_gamestate == gamestate.Menu)
            {
                spriteBatch.Draw(menubackground, new Rectangle(0, 0, 960, 832), Color.White);
                spriteBatch.Draw(playbutton, new Rectangle((int)playbutton_pos.X -335/2, (int)playbutton_pos.Y-86, 335, 86), Color.White);
                spriteBatch.Draw(optionsbutton, new Rectangle((int)optionsbutton_pos.X-335/2, (int)optionsbutton_pos.Y-86, 335, 86), Color.White);
                spriteBatch.Draw(quitbutton, new Rectangle((int)quitbutton_pos.X-335/2, (int)quitbutton_pos.Y-86, 335, 86), Color.White);
            }
            

            //Stop drawing
            spriteBatch.End();

            base.Draw(gameTime);
        }

        void MouseClicked(int x, int y)
        {
            //MB// Pour créer un rectangle de 1*1 autour de l'endroit où on a cliqué

            Rectangle mouseClickRect = new Rectangle(x, y, 1, 1);

            if(_gamestate == gamestate.Menu)
            {
                //MB// Il faut enlever -335/2 et -86 sinon la "hitbox" est pas au bon endroit
                Rectangle playButtonRect = new Rectangle((int)(playbutton_pos.X-335/2),(int)(playbutton_pos.Y-86), 335, 86);
                Rectangle quitButtonRect = new Rectangle((int)(quitbutton_pos.X-335/2),(int)quitbutton_pos.Y-86, 335, 86);
                if (mouseClickRect.Intersects(playButtonRect))
                {
                    _gamestate = gamestate.Running;                    
                }
                else if (mouseClickRect.Intersects(quitButtonRect))
                {
                    Exit();
                }
            }
        }
    }
}
