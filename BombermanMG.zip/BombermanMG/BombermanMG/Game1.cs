﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Input.Touch;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;

namespace BombermanMG
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {       
        //Pour gérer les graphismes
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        // Declaration des textures utilisées
        Texture2D Background, bloc_des, flamme, b_f, b_b, b_v, bombe1,bombe2,mur_detruit, bloc_indes;
        Texture2D B1H, B1B, B1G, B1D;
        Texture2D B2H, B2B, B2G, B2D;
        Texture2D playbutton, quitbutton, optionsbutton, menubackground,gameover,title;

        //Position des boutons
        Vector2 playbutton_pos, optionsbutton_pos, quitbutton_pos;

        // Déclaration des sons
        Song ambiance;
        SoundEffect explo, bonus;

        // Declaration de nos objets
        Partie partie;
        Bomber Bomber1;
        Bomber Bomber2;

        // Etat du jeu
        // Pour l'instant on se sert pas de Options
        enum gamestate
        {
            Menu,
            Options,
            Running,
            GameOver
        }
        gamestate _gamestate;

        // Keyboard states used to determine key presses
        KeyboardState currentKeyboardState;
        KeyboardState previousKeyboardState;

        //Mouse states used to track Mouse button press
        MouseState currentMouseState;
        MouseState previousMouseState;        

        // Taille d'une case 
        const int TileSize = 64;

        // pour la gestion des bombes, nombre de passages dans la boucle
        const int delay = 125;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            // Pour régler la largeur de la fenêtre (c'est 960 = 15*64 comme les tableaux font du 13*11 sans compter les bords)
            graphics.PreferredBackBufferWidth = 15 * TileSize;
            // Pour régler la hauteur de la fenêtre (c'est 832 = 13*64 comme les tableaux font du 13*11 sans compter les bords)
            graphics.PreferredBackBufferHeight = 13 * TileSize;
            // Pour centrer la fenêtre
            Window.Position = new Point((GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Width / 2) - (graphics.PreferredBackBufferWidth / 2), (GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Height / 2) - (graphics.PreferredBackBufferHeight / 2));
            graphics.ApplyChanges();

        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            IsMouseVisible = true;
            // Game Objects
            partie = new Partie();
            Bomber1 = new Bomber();
            Bomber2 = new Bomber();
            playbutton_pos = new Vector2(3 * TileSize +TileSize/2, 4 * TileSize+TileSize/2);
            optionsbutton_pos = new Vector2(3 * TileSize+TileSize/2, 7 * TileSize+TileSize/2);
            quitbutton_pos = new Vector2(3 * TileSize+TileSize/2, 10 * TileSize+TileSize/2);
            _gamestate = gamestate.Menu;

            //On appelle loadcontent pour avoir les textures
            LoadContent();
            //Load the bomber resources
            Vector2 bomber1position = new Vector2(TileSize, TileSize);
            Vector2 bomber2position = new Vector2(13 * TileSize, 11 * TileSize);

            //On appelle l'initialisation de chacun de nos objets
            Bomber1.Initialize(bomber1position, B1H, B1B, B1G, B1D);
            Bomber2.Initialize(bomber2position, B2H, B2B, B2G, B2D);
            partie.Initialize(bloc_des, bombe1, bombe2, flamme, mur_detruit, bloc_indes);

            base.Initialize();
            
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            Background = Content.Load<Texture2D>("FondJeu");
            B1H = Content.Load<Texture2D>("B1H");
            B1B = Content.Load<Texture2D>("B1B");
            B1G = Content.Load<Texture2D>("B1G");
            B1D = Content.Load<Texture2D>("B1D");
            B2H = Content.Load<Texture2D>("B2H");
            B2B = Content.Load<Texture2D>("B2B");
            B2G = Content.Load<Texture2D>("B2G");
            B2D = Content.Load<Texture2D>("B2D");
            bombe1 = Content.Load<Texture2D>("Bombe1");
            bombe2 = Content.Load<Texture2D>("Bombe2");
            bloc_des = Content.Load<Texture2D>("Mur");
            flamme = Content.Load<Texture2D>("Flamme");
            mur_detruit = Content.Load<Texture2D>("Mur_det");
            b_b = Content.Load<Texture2D>("Bonus_b");
            b_f = Content.Load<Texture2D>("Bonus_f");
            menubackground = Content.Load<Texture2D>("MenuBG2");
            playbutton = Content.Load<Texture2D>("Play_button1");
            optionsbutton = Content.Load<Texture2D>("Play_button2");
            quitbutton = Content.Load<Texture2D>("Quit_button");
            gameover = Content.Load<Texture2D>("gameover");
            bloc_indes = Content.Load<Texture2D>("Mur_indes");
            title = Content.Load<Texture2D>("Bomberman_Title");

            explo = Content.Load<SoundEffect>("8-bit explosion");
            bonus = Content.Load<SoundEffect>("8-bit bonus");

            ambiance = Content.Load<Song>("ambiance");
            MediaPlayer.Volume = 0f;
            MediaPlayer.Play(ambiance);

            

        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            
            if (Keyboard.GetState().IsKeyDown(Keys.Escape))
                _gamestate = gamestate.Menu;

            // TODO: Add your update logic here
            // Save the previous state of the keyboard and game pad so we can determine single key/button presses
            previousMouseState = currentMouseState;
            previousKeyboardState = currentKeyboardState;

            // Read the current state of the keyboard and gamepad and store it
            currentKeyboardState = Keyboard.GetState();
            currentMouseState = Mouse.GetState();            

            //Si on clique on appelle la fonction de gestion des clics (définie plus bas)
            if (previousMouseState.LeftButton == ButtonState.Pressed && currentMouseState.LeftButton == ButtonState.Released)
            {
                MouseClicked(currentMouseState.X, currentMouseState.Y);
            }

            //Si le jeu est lancé on appelle la mise à jour des données des Bombers
            if(_gamestate==gamestate.Running)
            {
                Update_Bomber1(gameTime);
                if (Bomber1.alive == false)
                {
                    Quit();
                }
                Update_Bomber2(gameTime);
                if (Bomber2.alive == false)
                {
                    Quit();
                }
                Update_Bomb(gameTime);
            }
            
            
            if(_gamestate == gamestate.GameOver)
            {
                //Si on est en game over on appuie sur entrée pour revenir au menu
                if(currentKeyboardState.IsKeyDown(Keys.Enter))
                {
                    _gamestate = gamestate.Menu;
                    //Lors d'un gameover on remet la partie à 0 pour pouvoir rejouer
                    for (int i = 0; i < 13; i++)
                    {
                        for (int j = 0; j < 11; j++)
                        {
                            partie.tab_blocs[i, j] = 0;
                            partie.tab_bombes[i, j] = 0;
                            partie.tab_bonus[i, j] = 0;
                        }
                    }
                    //On réinitialise les bombers
                    Initialize();
                }
            }

            base.Update(gameTime);
        }

        //Toutes les fonctions update qui suivent auraient pu être faites dans la fonctions update au dessus, d'ailleurs on les appelle
        //Mais dans un souci de clarté nous avons préféré subdiviser les update
        private void Update_Bomber1(GameTime gameTime)
        {
            //Le nom de la variable n'est pas très parlant
            //Elle sert à empêcher de faire plusieurs mouvements à la fois
            //comme Updatebomber1 est une boucle et qu'elle scanne les déplacements dans un certain ordre
            //On pourrait faire plusieurs déplacements en une boucle
            //Cela créerait des déplacements en diagonale, qu'on ne veut pas puisqu'on se déplace de case en case
            bool movement = true;

            // on teste si le joueur est dans une flamme
            if (partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] == 3)
            {
                Bomber1.alive = false;
            }

            //Si on appuie sur Q et uniquement Q
            if (currentKeyboardState.IsKeyDown(Keys.Q) && movement
                && currentKeyboardState.IsKeyUp(Keys.S) && currentKeyboardState.IsKeyUp(Keys.D) && currentKeyboardState.IsKeyUp(Keys.Z))
            {
                //Si on est pas au bord
                if (Bomber1.pos.X > TileSize)
                {
                    //on regarde que la case à gauche n'est occupée ni par une bombe ni par un mur
                    if (partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber1.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber1.pos.Y / TileSize) - 1] != 2
                        && partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber1.pos.Y / TileSize) - 1] != 41
                        && partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber1.pos.Y / TileSize) - 1] != 42)
                    {
                        //On change la position
                        Bomber1.pos.X -= Bomber1.vitesse;
                        //on change la direction pour l'affichage du bomber
                        Bomber1.dir = 2;
                        // Pareil ici on teste si le joueur est dans une flamme en cours de mouvement
                        if (partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] == 3)
                        {
                            Bomber1.alive = false;
                        }
                        //Si on a fait ce mouvement on n'en fera pas d'autre de la boucle Update
                        movement = false;
                    }                 
                }

            }
            //Si on a commencé un mouvement à gauche
            else if (previousKeyboardState.IsKeyDown(Keys.Q))
            {
                //on regarde que la case où on veut finir est libre
                if (Bomber1.pos.X > TileSize)
                {
                    // Gestion de collision
                    //                   
                    // Le type de bloc sur le terrain est renseigné dans partie.tab_blocs[]
                    // On convertit la position du bomber à l'écran, donnée en pixels, en une position dans le tableau
                    // Pour ça on divise la position à l'écran par Tilesize(64) puisque le tableau fait 13*11
                    // Et que la partie jouable de l'écran fait 13Tilesize * 11Tilesize
                    // On garde la partie entière de cette division au cas où on serait en mouvement
                    // On obtient donc un nombre entre 1 et 13. On lui retranche 1 car l'indice du tableau va de 0 à 12
                    // Maintenant comme c'est un déplacement à gauche on regarde la case à gauche du bomber dans le tableau
                    // Il suffit de faire -1 sur pos.X du bomber. C'est pour ça qu'on a -2 pour le X et -1 pour le Y
                    // L'histoire du +Tilesize -1 c'est pour prendre en compte non pas le bord gauche du bomber (par défaut)
                    // Si on effectue le test sur le bord gauche, il suffit qu'on se décale d'un pixel et la condition
                    // n'est plus vraie. En faisant -Tilesize +1 on prend en compte le bord droit du bomber
                    // Et comme ça la condition devient fausse uniquement quand le bomber est entièrement dans la case
                    if (partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber1.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber1.pos.Y / TileSize) - 1] != 2
                        && partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber1.pos.Y / TileSize) - 1] != 41
                        && partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber1.pos.Y / TileSize) - 1] != 42)
                    {
                        //Et on finit le déplacement sur une case entière
                        //Cela va faciliter le calcul de la position du bomber, des collisions et la pose de bombes
                        while (Bomber1.pos.X != ((int)Bomber1.pos.X / TileSize) * TileSize)
                        {
                            Bomber1.pos.X -= Bomber1.vitesse;
                            Bomber1.dir = 2;
                            //Si le mouvement finit dans une flamme
                            if (partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] == 3)
                            {
                                Bomber1.alive = false;
                            }
                        }
                        //Si on a fait ce mouvement on n'en fera pas d'autre de la boucle Update
                        movement = false;
                    }
                }                   
                    
            }

            //Même démarche pour la droite
            if (currentKeyboardState.IsKeyDown(Keys.D) == true &&movement
                && currentKeyboardState.IsKeyUp(Keys.S) && currentKeyboardState.IsKeyUp(Keys.Q) && currentKeyboardState.IsKeyUp(Keys.Z))
            {
                if (Bomber1.pos.X < 13 * TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 2
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 41
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 42)
                    {
                        Bomber1.pos.X += Bomber1.vitesse;
                        Bomber1.dir = 3;
                        if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize)-1, (int)(Bomber1.pos.Y / TileSize) - 1] == 3)
                        {
                            Bomber1.alive = false;
                        }
                    }
                    movement = false;
                }

            }
            else if (previousKeyboardState.IsKeyDown(Keys.D))
            {
                if (Bomber1.pos.X < 13 * TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 2
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 41
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize), (int)(Bomber1.pos.Y / TileSize) - 1] != 42)
                    {
                        while (Bomber1.pos.X != ((int)Bomber1.pos.X / TileSize) * TileSize)
                        {
                            Bomber1.pos.X++;
                            Bomber1.dir = 3;
                            if (partie.tab_blocs[(int)((Bomber1.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] == 3)
                            {
                                Bomber1.alive = false;
                            }
                        }
                    }

                    movement = false;
                }
                    
            }

            if (currentKeyboardState.IsKeyDown(Keys.Z) == true && movement
                && currentKeyboardState.IsKeyUp(Keys.S) && currentKeyboardState.IsKeyUp(Keys.D) && currentKeyboardState.IsKeyUp(Keys.Q))
            {
                if (Bomber1.pos.Y > TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 2] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 2] != 2
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 2] != 41
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 2] != 42)
                    {
                        Bomber1.pos.Y -= Bomber1.vitesse;
                        Bomber1.dir = 0;
                        if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 1] == 3)
                        {
                            Bomber1.alive = false;
                        }
                    }
                    movement = false;
                }

            }
            else if (previousKeyboardState.IsKeyDown(Keys.Z))
            {
                if (Bomber1.pos.Y > TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 2] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 2] != 2
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 2] != 41
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 2] != 42)
                    {
                        while (Bomber1.pos.Y != ((int)Bomber1.pos.Y / TileSize) * TileSize)
                        {
                            Bomber1.pos.Y--;
                            Bomber1.dir = 0;
                            if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y + TileSize - 1) / TileSize) - 1] == 3)
                            {
                                Bomber1.alive = false;
                            }
                        }
                        movement = false;
                    }
                }                  
                    
            }


            if (currentKeyboardState.IsKeyDown(Keys.S) == true &&movement
                && currentKeyboardState.IsKeyUp(Keys.Q) && currentKeyboardState.IsKeyUp(Keys.D) && currentKeyboardState.IsKeyUp(Keys.Z))
            {
                if (Bomber1.pos.Y < 11 * TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)] != 2
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)] != 41
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)] != 42)
                    {
                        Bomber1.pos.Y += Bomber1.vitesse;
                        Bomber1.dir = 1;
                        if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)-1] == 3)
                        {
                            Bomber1.alive = false;
                        }
                    }
                    movement = false;
                }
            }
            else if (previousKeyboardState.IsKeyDown(Keys.S))
            {
                if (Bomber1.pos.Y < 11 * TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)] != 1
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)] != 2
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)] != 41
                        && partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize)] != 42)
                    {
                        while (Bomber1.pos.Y != ((int)Bomber1.pos.Y / TileSize) * TileSize)
                        {
                            Bomber1.pos.Y++;
                            Bomber1.dir = 1;
                            if (partie.tab_blocs[(int)((Bomber1.pos.X) / TileSize) - 1, (int)((Bomber1.pos.Y) / TileSize) - 1] == 3)
                            {
                                Bomber1.alive = false;
                            }
                        }
                        movement = false;
                    }
                }                    
                    
            }

            // Pose des bombes
            //Si on appuie sur espace (on détecte la relâche de la touche cela évite les problèmes avec l'incrémentation du nb de bombes posées
            if (currentKeyboardState.IsKeyUp(Keys.Space) && previousKeyboardState.IsKeyDown(Keys.Space))
            {
                //Si le joueur n'a pas atteint son nb de bombes simultanées max
                if(Bomber1.nb_bombes_pos < Bomber1.nb_bombes)
                {
                    //On met le tableau à 41 (4 pour bombe et 1 pour joueur 1)
                    partie.tab_blocs[(int)(Bomber1.pos.X / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] = 41;
                    //On met le tableau de bombes à delay pour gérer le temps avant explosion
                    partie.tab_bombes[(int)(Bomber1.pos.X / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] = delay;
                    //On augmente le nombres de bombes du joueur actuellement sur le terrain
                    Bomber1.nb_bombes_pos++;
                }
                
            }

            //Gestion des bonus
            //On regarde si dans le tableau de bonus à la position du joueur il y a un bonus et on l'applique le cas échéant
            switch (partie.tab_bonus[(int)(Bomber1.pos.X / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1])
            {
                case 1:
                    Bomber1.puissance++;
                    //Le bonus disparait
                    partie.tab_bonus[(int)(Bomber1.pos.X / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] = 0;
                    //on joue l'effet sonore de bonus
                    bonus.Play();
                    break;
                case 2:
                    Bomber1.nb_bombes++;
                    partie.tab_bonus[(int)(Bomber1.pos.X / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] = 0;
                    bonus.Play();
                    break;

                  /*case 3:
                        Bomber1.vitesse++;
                        partie.tab_bonus[(int)(Bomber1.pos.X / TileSize) - 1, (int)(Bomber1.pos.Y / TileSize) - 1] = 0;
                        bonus.Play();
                        break;*/
                }
            
        }
        
        private void Update_Bomber2(GameTime gameTime)
        {
            //Le nom de la variable n'est pas très parlant
            //Elle sert à empêcher de faire plusieurs mouvements à la fois
            //comme Updatebomber2 est une boucle et qu'elle scanne les déplacements dans un certain ordre
            //On pourrait faire plusieurs déplacements en une boucle
            //Cela créerait des déplacements en diagonale, qu'on ne veut pas puisqu'on se déplace de case en case
            bool movement = true;

            // on teste si le joueur est dans une flamme
            if (partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] == 3)
            {
                Bomber2.alive = false;
            }

            //Si on appuie sur Q et uniquement Q
            if (currentKeyboardState.IsKeyDown(Keys.Left) && movement
                && currentKeyboardState.IsKeyUp(Keys.Down) && currentKeyboardState.IsKeyUp(Keys.Right) && currentKeyboardState.IsKeyUp(Keys.Up))
            {
                //Si on est pas au bord
                if (Bomber2.pos.X > TileSize)
                {
                    //on regarde que la case à gauche n'est occupée ni par une bombe ni par un mur
                    if (partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber2.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber2.pos.Y / TileSize) - 1] != 2
                        && partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber2.pos.Y / TileSize) - 1] != 41
                        && partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber2.pos.Y / TileSize) - 1] != 42)
                    {
                        //On change la position
                        Bomber2.pos.X -= Bomber2.vitesse;
                        //on change la direction pour l'affichage du bomber
                        Bomber2.dir = 2;
                        // Pareil ici on teste si le joueur est dans une flamme en cours de mouvement
                        if (partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] == 3)
                        {
                            Bomber2.alive = false;
                        }
                        //Si on a fait ce mouvement on n'en fera pas d'autre de la boucle Update
                        movement = false;
                    }
                }

            }
            //Si on a commencé un mouvement à gauche
            else if (previousKeyboardState.IsKeyDown(Keys.Left))
            {
                //on regarde que la case où on veut finir est libre
                if (Bomber2.pos.X > TileSize)
                {
                    // Gestion de collision
                    //                   
                    // Le type de bloc sur le terrain est renseigné dans partie.tab_blocs[]
                    // On convertit la position du bomber à l'écran, donnée en pixels, en une position dans le tableau
                    // Pour ça on divise la position à l'écran par Tilesize(64) puisque le tableau fait 13*11
                    // Et que la partie jouable de l'écran fait 13Tilesize * 11Tilesize
                    // On garde la partie entière de cette division au cas où on serait en mouvement
                    // On obtient donc un nombre entre 1 et 13. On lui retranche 1 car l'indice du tableau va de 0 à 12
                    // Maintenant comme c'est un déplacement à gauche on regarde la case à gauche du bomber dans le tableau
                    // Il suffit de faire -1 sur pos.X du bomber. C'est pour ça qu'on a -2 pour le X et -1 pour le Y
                    // L'histoire du +Tilesize -1 c'est pour prendre en compte non pas le bord gauche du bomber (par défaut)
                    // Si on effectue le test sur le bord gauche, il suffit qu'on se décale d'un pixel et la condition
                    // n'est plus vraie. En faisant -Tilesize +1 on prend en compte le bord droit du bomber
                    // Et comme ça la condition devient fausse uniquement quand le bomber est entièrement dans la case
                    if (partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber2.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber2.pos.Y / TileSize) - 1] != 2
                        && partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber2.pos.Y / TileSize) - 1] != 41
                        && partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 2, (int)(Bomber2.pos.Y / TileSize) - 1] != 42)
                    {
                        //Et on finit le déplacement sur une case entière
                        //Cela va faciliter le calcul de la position du bomber, des collisions et la pose de bombes
                        while (Bomber2.pos.X != ((int)Bomber2.pos.X / TileSize) * TileSize)
                        {
                            Bomber2.pos.X -= Bomber2.vitesse;
                            Bomber2.dir = 2;
                            //Si le mouvement finit dans une flamme
                            if (partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] == 3)
                            {
                                Bomber2.alive = false;
                            }
                        }
                        //Si on a fait ce mouvement on n'en fera pas d'autre de la boucle Update
                        movement = false;
                    }
                }

            }

            //Même démarche pour la droite
            if (currentKeyboardState.IsKeyDown(Keys.Right) == true && movement
                && currentKeyboardState.IsKeyUp(Keys.Down) && currentKeyboardState.IsKeyUp(Keys.Left) && currentKeyboardState.IsKeyUp(Keys.Up))
            {
                if (Bomber2.pos.X < 13 * TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize), (int)(Bomber2.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize), (int)(Bomber2.pos.Y / TileSize) - 1] != 2
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize), (int)(Bomber2.pos.Y / TileSize) - 1] != 41
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize), (int)(Bomber2.pos.Y / TileSize) - 1] != 42)
                    {
                        Bomber2.pos.X += Bomber2.vitesse;
                        Bomber2.dir = 3;
                        if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] == 3)
                        {
                            Bomber2.alive = false;
                        }
                    }
                    movement = false;
                }

            }
            else if (previousKeyboardState.IsKeyDown(Keys.Right))
            {
                if (Bomber2.pos.X < 13 * TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize), (int)(Bomber2.pos.Y / TileSize) - 1] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize), (int)(Bomber2.pos.Y / TileSize) - 1] != 2
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize), (int)(Bomber2.pos.Y / TileSize) - 1] != 41
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize), (int)(Bomber2.pos.Y / TileSize) - 1] != 42)
                    {
                        while (Bomber2.pos.X != ((int)Bomber2.pos.X / TileSize) * TileSize)
                        {
                            Bomber2.pos.X++;
                            Bomber2.dir = 3;
                            if (partie.tab_blocs[(int)((Bomber2.pos.X + TileSize - 1) / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] == 3)
                            {
                                Bomber2.alive = false;
                            }
                        }
                    }

                    movement = false;
                }

            }

            if (currentKeyboardState.IsKeyDown(Keys.Up) == true && movement
                && currentKeyboardState.IsKeyUp(Keys.Down) && currentKeyboardState.IsKeyUp(Keys.Right) && currentKeyboardState.IsKeyUp(Keys.Left))
            {
                if (Bomber2.pos.Y > TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 2
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 41
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 42)
                    {
                        Bomber2.pos.Y -= Bomber2.vitesse;
                        Bomber2.dir = 0;
                        if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 1] == 3)
                        {
                            Bomber2.alive = false;
                        }
                    }
                    movement = false;
                }

            }
            else if (previousKeyboardState.IsKeyDown(Keys.Up))
            {
                if (Bomber2.pos.Y > TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 2
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 41
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 2] != 42)
                    {
                        while (Bomber2.pos.Y != ((int)Bomber2.pos.Y / TileSize) * TileSize)
                        {
                            Bomber2.pos.Y--;
                            Bomber2.dir = 0;
                            if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y + TileSize - 1) / TileSize) - 1] == 3)
                            {
                                Bomber2.alive = false;
                            }
                        }
                        movement = false;
                    }
                }

            }


            if (currentKeyboardState.IsKeyDown(Keys.Down) == true && movement
                && currentKeyboardState.IsKeyUp(Keys.Left) && currentKeyboardState.IsKeyUp(Keys.Right) && currentKeyboardState.IsKeyUp(Keys.Up))
            {
                if (Bomber2.pos.Y < 11 * TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y) / TileSize)] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y) / TileSize)] != 2
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y) / TileSize)] != 41
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y) / TileSize)] != 42)
                    {
                        Bomber2.pos.Y += Bomber2.vitesse;
                        Bomber2.dir = 1;
                        if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y) / TileSize) - 1] == 3)
                        {
                            Bomber2.alive = false;
                        }
                    }
                    movement = false;
                }
            }
            else if (previousKeyboardState.IsKeyDown(Keys.Down))
            {
                if (Bomber2.pos.Y < 11 * TileSize)
                {
                    if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y) / TileSize)] != 1
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y) / TileSize)] != 2
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y) / TileSize)] != 41
                        && partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y) / TileSize)] != 42)
                    {
                        while (Bomber2.pos.Y != ((int)Bomber2.pos.Y / TileSize) * TileSize)
                        {
                            Bomber2.pos.Y++;
                            Bomber2.dir = 1;
                            if (partie.tab_blocs[(int)((Bomber2.pos.X) / TileSize) - 1, (int)((Bomber2.pos.Y) / TileSize) - 1] == 3)
                            {
                                Bomber2.alive = false;
                            }
                        }
                        movement = false;
                    }
                }

            }

            // Pose des bombes
            //Si on appuie sur 0 (on détecte la relâche de la touche cela évite les problèmes avec l'incrémentation du nb de bombes posées
            if (currentKeyboardState.IsKeyUp(Keys.NumPad0) && previousKeyboardState.IsKeyDown(Keys.NumPad0))
            {
                //Si le joueur n'a pas atteint son nb de bombes simultanées max
                if (Bomber2.nb_bombes_pos < Bomber2.nb_bombes)
                {
                    //On met le tableau à 41 (4 pour bombe et 1 pour joueur 1)
                    partie.tab_blocs[(int)(Bomber2.pos.X / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] = 42;
                    //On met le tableau de bombes à delay pour gérer le temps avant explosion
                    partie.tab_bombes[(int)(Bomber2.pos.X / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] = delay;
                    //On augmente le nombres de bombes du joueur actuellement sur le terrain
                    Bomber2.nb_bombes_pos++;
                }

            }

            //Gestion des bonus
            //On regarde si dans le tableau de bonus à la position du joueur il y a un bonus et on l'applique le cas échéant
            switch (partie.tab_bonus[(int)(Bomber2.pos.X / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1])
            {
                case 1:
                    Bomber2.puissance++;
                    //Le bonus disparait
                    partie.tab_bonus[(int)(Bomber2.pos.X / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] = 0;
                    //on joue l'effet sonore de bonus
                    bonus.Play();
                    break;
                case 2:
                    Bomber2.nb_bombes++;
                    partie.tab_bonus[(int)(Bomber2.pos.X / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] = 0;
                    bonus.Play();
                    break;

                    /*case 3:
                          Bomber2.vitesse++;
                          partie.tab_bonus[(int)(Bomber2.pos.X / TileSize) - 1, (int)(Bomber2.pos.Y / TileSize) - 1] = 0;
                          bonus.Play();
                          break;*/
            }

        }

        private void Update_Bomb(GameTime gameTime)
        {            
            for(int i=0;i<13;i++)
            {
                for(int j =0;j<11;j++)
                {
                    // Si la valeur dans le tableau est positive c'est une bombe
                    if(partie.tab_bombes[i,j] >0)
                    {
                        //Cette valuer positive sert aussi de timer pour gérer l'explosion
                        partie.tab_bombes[i, j]--;
                        //quand on arrive à 0 on fait exploser la bombe
                        if(partie.tab_bombes[i,j]==0)
                        {
                            //Et selon le joueur qui a posé la bombe on lui enlève un à son compte de bombes sur le terrain
                            switch (partie.tab_blocs[i, j])
                            {
                                case 41:
                                    Bomber1.nb_bombes_pos--;
                                    break;
                                case 42:
                                    Bomber2.nb_bombes_pos--;
                                    break;
                            }
                            Explosion(i,j);                            
                        }
                    }
                    // Si la valeur est négative c'est une flamme
                    //Et pareil on s'en sert de timer
                    if(partie.tab_bombes[i,j]<0)
                    {
                        partie.tab_bombes[i, j]++;
                        //quand le timer arrive au bout on fait disparaître les flammes
                        if(partie.tab_bombes[i,j]==0)
                        {
                            partie.tab_blocs[i, j] = 0;
                        }
                    }
                }
            }            
        }

        private void Explosion(int x,int y)
        {
            //Variable pour récupérer la puissance de la bombe en fonction du joueur qui l'a posée
            int p;            
            switch (partie.tab_blocs[x,y])
            {
                case 41:
                    //La case où était la bombe devient vide
                    partie.tab_blocs[x, y] = 0;
                    partie.tab_bombes[x, y] = 0;
                    p = Bomber1.puissance;
                    //on joue le son de l'explosion
                    explo.Play();
                    //4 boucles pour les 4 directions
                    for(int i =0;i<=p;i++)
                    {
                        //Tant qu'on ne sort pas des tableaux
                        if(x+i <13)
                        {
                            //on regarde si on peut mettre une flamme à droite
                            switch (partie.tab_blocs[x + i, y])
                            {
                                //S'il n'y a rien on peut
                                case 0:
                                    partie.tab_blocs[x + i, y] = 3;
                                    partie.tab_bombes[x + i, y] = -delay/2;
                                    if(partie.tab_bonus[x+i,y] !=0)
                                    {
                                        partie.tab_bonus[x + i, y] = 0;
                                    }
                                    break;
                                //Si c'est un mur destructible on le détruit et on ne va pas plus loin dans cette direction
                                case 2:
                                    //21 correspond à un bloc en cours de destruction
                                    partie.tab_blocs[x + i, y] = 21;
                                    partie.tab_bombes[x + i, y] = -delay/2;
                                    i = p+1;
                                    break;
                                //Si c'est un mur indestructible on le détruit et on ne va pas plus loin dans cette direction
                                case 1:
                                    i = p + 1;
                                    break;
                            }
                        }
                        
                    }
                    //On fait pareil vers le bas
                    for (int i = 0; i <= p; i++)
                    {
                        if(y+i < 11)
                        {
                            switch (partie.tab_blocs[x, y + i])
                            {
                                case 0:
                                    partie.tab_blocs[x, y + i] = 3;
                                    partie.tab_bombes[x , y +i] = -delay/2;
                                    if (partie.tab_bonus[x, y+i] != 0)
                                    {
                                        partie.tab_bonus[x, y+i] = 0;
                                    }
                                    break;
                                case 2:
                                    partie.tab_blocs[x, y + i] = 21;
                                    partie.tab_bombes[x , y+i] = -delay / 2;
                                    //Si on rencontre un mur on arrête l'explosion dans cette direction
                                    i = p+1;
                                    break;
                                case 1:
                                    i = p + 1;
                                    break;
                            }
                        }
                        
                    }
                    //Vers la gauche
                    for (int i = 0; i <= p; i++)
                    {
                        if(x-i>=0)
                        {
                            switch (partie.tab_blocs[x - i, y])
                            {
                                case 0:
                                    partie.tab_blocs[x - i, y] = 3;
                                    partie.tab_bombes[x - i, y] = -delay/2;
                                    if (partie.tab_bonus[x - i, y] != 0)
                                    {
                                        partie.tab_bonus[x - i, y] = 0;
                                    }
                                    break;
                                case 2:
                                    partie.tab_blocs[x - i, y] = 21;
                                    partie.tab_bombes[x - i, y] = -delay / 2;
                                    //Si on rencontre un mur on arrête l'explosion dans cette direction
                                    i = p;
                                    break;
                                case 1:
                                    i = p + 1;
                                    break;
                            }
                        }
                        
                    }
                    //vers le haut
                    for (int i = 0; i <= p; i++)
                    {
                        if(y-i>=0)
                        {
                            switch (partie.tab_blocs[x, y - i])
                            {
                                case 0:
                                    partie.tab_blocs[x, y - i] = 3;
                                    partie.tab_bombes[x , y - i] = -delay/2;
                                    if (partie.tab_bonus[x, y-i] != 0)
                                    {
                                        partie.tab_bonus[x, y-i] = 0;
                                    }
                                    break;
                                case 2:
                                    partie.tab_blocs[x, y - i] = 21;
                                    partie.tab_bombes[x , y-i] = -delay / 2;
                                    //Si on rencontre un mur on arrête l'explosion dans cette direction
                                    i = p;
                                    break;
                                case 1:
                                    i = p + 1;
                                    break;
                            }
                        }
                        
                    }
                    break;

                // tout pareil mais pour le joueur 2
                case 42:                    
                    partie.tab_blocs[x, y] = 0;
                    partie.tab_bombes[x, y] = 0;
                    p = Bomber2.puissance;
                    explo.Play();
                    for (int i = 0; i <= p; i++)
                    {
                        if (x+i <13)
                        {
                            switch (partie.tab_blocs[x+i, y])
                            {
                                case 0:
                                    partie.tab_blocs[x+i, y] = 3;
                                    partie.tab_bombes[x + i, y] = -delay/2;
                                    if (partie.tab_bonus[x + i, y] != 0)
                                    {
                                        partie.tab_bonus[x + i, y] = 0;
                                    }
                                    break;
                                case 2:
                                    partie.tab_blocs[x+i, y] = 21;
                                    partie.tab_bombes[x + i, y] = -delay / 2;
                                    i = p;
                                    break;
                                case 1:
                                    i = p + 1;
                                    break;
                            }
                        }
                    }
                    for (int i = 0; i <= p; i++)
                    {
                        if (y+i < 11)
                        {
                            switch (partie.tab_blocs[x, y + i])
                            {
                                case 0:
                                    partie.tab_blocs[x, y + i] = 3;
                                    partie.tab_bombes[x , y+i] = -delay/2;
                                    if (partie.tab_bonus[x, y+i] != 0)
                                    {
                                        partie.tab_bonus[x, y+i] = 0;
                                    }
                                    break;
                                case 2:
                                    partie.tab_blocs[x, y + i] = 21;
                                    partie.tab_bombes[x , y+i] = -delay / 2;
                                    i = p;
                                    break;
                                case 1:
                                    i = p + 1;
                                    break;
                            }
                        }
                    }
                    for (int i = 0; i <= p; i++)
                    {
                        if (x-i >= 0)
                        {
                            switch (partie.tab_blocs[x-i, y])
                            {
                                case 0:
                                    partie.tab_blocs[x-i, y] = 3;
                                    partie.tab_bombes[x - i, y] = -delay/2;
                                    if (partie.tab_bonus[x - i, y] != 0)
                                    {
                                        partie.tab_bonus[x - i, y] = 0;
                                    }
                                    break;
                                case 2:
                                    partie.tab_blocs[x-i, y] = 21;
                                    partie.tab_bombes[x - i, y] = -delay / 2;
                                    i = p;
                                    break;
                                case 1:
                                    i = p + 1;
                                    break;
                            }
                        }
                    }
                    for (int i = 0; i <= p; i++)
                    {
                        if (y-i >= 0)
                        {
                            switch (partie.tab_blocs[x, y - i])
                            {
                                case 0:
                                    partie.tab_blocs[x, y - i] = 3;
                                    partie.tab_bombes[x , y-i] = -delay/2;
                                    if (partie.tab_bonus[x, y-i] != 0)
                                    {
                                        partie.tab_bonus[x, y-i] = 0;
                                    }
                                    break;
                                case 2:
                                    partie.tab_blocs[x, y - i] = 21;
                                    partie.tab_bombes[x , y-i] = -delay / 2;
                                    i = p;
                                    break;
                                case 1:
                                    i = p + 1;
                                    break;
                            }
                        }
                    }
                    break;
            }
        }

        //On a fait la fonction d'affichage ici et pas dans la classe partie pour ne pas avoir tout plein de textures à passer en paramètre
        //de l'initialize de la partie
        private void Draw_Bonus(SpriteBatch spriteBatch)
        {
            for(int i=0;i<13;i++)
            {
                for(int j=0;j<11;j++)
                {
                    if(partie.tab_blocs[i,j]==0)
                    {
                        switch (partie.tab_bonus[i, j])
                        {
                            //bonus flamme
                            case 1:
                                spriteBatch.Draw(b_f, new Rectangle((i + 1) * TileSize, (j + 1) * TileSize, TileSize, TileSize), Color.White);
                                break;
                            //bonus bombe
                            case 2:
                                spriteBatch.Draw(b_b, new Rectangle((i + 1) * TileSize, (j + 1) * TileSize, TileSize, TileSize), Color.White);
                                break;
                        }
                    }                    
                }
            }
        }


        // Dans cette méthode on pourra rajouter le code de ce qu'on voudra faire en fin de partie en fonction du joueur qui a perdu
        private void Quit()
        {
            if(Bomber1.alive == false)
            {               
                _gamestate = gamestate.GameOver;
            }
            else
            {
                _gamestate = gamestate.GameOver;
            }
        }

        
        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here

            //start drawing
            spriteBatch.Begin();

            //On aurait pu faire un switch

            if(_gamestate == gamestate.Running)
            {
                spriteBatch.Draw(Background, new Rectangle(0, 0, 960, 832), Color.White);
                Bomber1.Draw(spriteBatch);
                Bomber2.Draw(spriteBatch);
                partie.Draw(spriteBatch);
                Draw_Bonus(spriteBatch);
            }

            if(_gamestate == gamestate.Menu)
            {
                spriteBatch.Draw(menubackground, new Rectangle(0, 0, 960, 832), Color.White);
                spriteBatch.Draw(playbutton, new Rectangle((int)playbutton_pos.X -335/2, (int)playbutton_pos.Y-86, 335, 86), Color.White);
                spriteBatch.Draw(optionsbutton, new Rectangle((int)optionsbutton_pos.X-335/2, (int)optionsbutton_pos.Y-86, 335, 86), Color.White);
                spriteBatch.Draw(quitbutton, new Rectangle((int)quitbutton_pos.X-335/2, (int)quitbutton_pos.Y-86, 335, 86), Color.White);
                spriteBatch.Draw(title, new Rectangle(100, 0, 760, 170), Color.White);
            }

            if(_gamestate == gamestate.GameOver)
            {
                spriteBatch.Draw(Background, new Rectangle(0, 0, 960, 832), Color.White);
                Bomber1.Draw(spriteBatch);
                Bomber2.Draw(spriteBatch);
                partie.Draw(spriteBatch);
                spriteBatch.Draw(gameover, new Rectangle(0, 0, 960, 832), Color.White);
            }

            if(_gamestate == gamestate.Options)
            {
                
            }
            

            //Stop drawing
            spriteBatch.End();

            base.Draw(gameTime);
        }

        void MouseClicked(int x, int y)
        {
            // On crée un rectangle de 1*1 autour de l'endroit où on a cliqué

            Rectangle mouseClickRect = new Rectangle(x, y, 1, 1);

            if(_gamestate == gamestate.Menu)
            {
                // Il faut enlever -335/2 et -86 sinon la "hitbox" du bouton est pas au bon endroit
                Rectangle playButtonRect = new Rectangle((int)(playbutton_pos.X-335/2),(int)(playbutton_pos.Y-86), 335, 86);
                Rectangle quitButtonRect = new Rectangle((int)(quitbutton_pos.X-335/2),(int)quitbutton_pos.Y-86, 335, 86);
                Rectangle optionsButtonRect = new Rectangle((int)(optionsbutton_pos.X - 335 / 2), (int)(optionsbutton_pos.Y - 86), 335, 86);
                if (mouseClickRect.Intersects(playButtonRect))
                {
                    _gamestate = gamestate.Running;                    
                }
                else if (mouseClickRect.Intersects(quitButtonRect))
                {
                    Exit();
                }
                else if (mouseClickRect.Intersects(optionsButtonRect))
                {
                    _gamestate = gamestate.Options;
                }
            }
        }
    }
}
